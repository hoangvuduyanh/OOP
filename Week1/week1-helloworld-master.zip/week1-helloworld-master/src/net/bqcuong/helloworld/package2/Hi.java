package net.bqcuong.helloworld.package2;

public class Hi {
    public static void print() {
        System.out.println("Hi World");
    }
}
