package net.bqcuong.helloworld.package1;

public class HelloWorld {
    public static void print() {
        System.out.println("Hello World");
    }
}
