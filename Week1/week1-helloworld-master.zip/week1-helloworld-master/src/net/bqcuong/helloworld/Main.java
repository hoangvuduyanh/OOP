package net.bqcuong.helloworld;

import net.bqcuong.helloworld.package1.HelloWorld;
import net.bqcuong.helloworld.package2.Hi;

public class Main {
    public static void main(String[] args) {
        HelloWorld.print();
        Hi.print();
    }
}
