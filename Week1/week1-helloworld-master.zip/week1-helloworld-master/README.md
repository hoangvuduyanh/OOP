# week1-helloworld
Dùng lệnh `javac` và `java` để biên dịch và chạy lớp `Main` trong package `net.bqcuong.helloworld` (không được dùng `cd src`)

Expected Output (Đầu ra mong muốn)
```
Hello World
Hi World
```

*Hướng dẫn*: Dùng thêm các tham số `-sourcepath` và `-classpath`
